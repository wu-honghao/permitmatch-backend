import { defineConfig, configDefaults } from "vitest/config";

export default defineConfig({
    test: {
        exclude: [
            ...configDefaults.exclude,
            "**/dist/**"
        ],
        setupFiles: ["./src/test/setup.ts"],
        hookTimeout: 15000
    }
});